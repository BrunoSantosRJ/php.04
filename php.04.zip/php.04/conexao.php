<?php

$con = mysqli_connect("localhost","root","","zezinho_info_tech");
mysqli_set_charset($con, "utf8");

?>